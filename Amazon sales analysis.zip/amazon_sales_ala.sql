-- Creating Amazon Database and Data Wrangling 

CREATE DATABASE if not exists Amazon; 

-- Making connection to database 

use Amazon;

SELECT * FROM amazon;

-- Renaming the columns with white spaces 

ALTER TABLE amazon 
RENAME COLUMN `Invoice ID` TO `Invoice_ID`;

ALTER TABLE amazon 
RENAME COLUMN `Customer type` TO `Customer_type`;

ALTER TABLE amazon 
RENAME COLUMN `Product line` TO `Product_line`;

ALTER TABLE amazon 
RENAME COLUMN `Unit price` TO `Unit_price`;

ALTER TABLE amazon 
RENAME COLUMN `Tax_5%` TO `Tax_5_percent`;

ALTER TABLE amazon 
RENAME column `gross margin percentage` TO `gross_margin_percentage`;

ALTER TABLE amazon 
RENAME column `gross income` TO `gross_income`;

-- checking the datatypes of the columns in table 

SELECT column_name, DATA_TYPE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_SCHEMA = 'amazon'
AND TABLE_NAME = 'amazon';

-- changing datatypes to required type 
ALTER TABLE amazon 
MODIFY Date Date;

ALTER TABLE amazon 
MODIFY Time TimeStamp;



-- Checking the null values in the dataset 

SELECT * FROM amazoN 
WHERE Quantity IS NULL OR 
		Invoice_ID is null OR 
        Branch IS NULL OR 
        City IS NULL OR 
        Customer_type IS NULL OR 
        Gender IS NULL OR 
        Product_line IS NULL OR 
        Unit_Price IS NULL OR 
        Tax_5_percent is null OR 
        Total IS NULL OR 
        Date IS NULL OR 
        Time IS NULL OR 
        Payment IS NULL OR 
        cogs IS NULL OR 
        gross_margin_percentage IS NULL OR 
        gross_incom IS NULL OR 
        Rating IS NULL;

-- There are no null values in the dataset since there were NOT NULL constraint added while creating table 


-- # Feature Engineering 

SELECT * FROM amazon;

-- Addign day_name column in the table 
SET SQL_SAFE_UPDATES=1;  -- Here we need to off the safe update mode first to do this operation 

-- Addign column 

ALTER TABLE amazon 
ADD COLUMN day_of_week varchar(10);

-- Updating values 
UPDATE amazon 
SET day_of_week=DAYNAME(Date);

SELECT * FROM amazon;


-- Addign column time_of_day 
ALTER TABLE amazon 
ADD COLUMN time_of_day VARCHAR(10);

SET SQL_SAFE_UPDATES=0;

-- Updating time of the day values 

UPDATE amazon
SET time_of_day = 
    CASE 
        WHEN EXTRACT(HOUR FROM Time) BETWEEN 6 AND 11 THEN 'Morning'
        WHEN EXTRACT(HOUR FROM Time) BETWEEN 12 AND 17 THEN 'Afternoon'
        WHEN EXTRACT(HOUR FROM Time) BETWEEN 18 AND 23 THEN 'Evening'
        ELSE 'Night'
    END;
    
SELECT* FROM amazon;

ALTER TABLE amazon 
ADD COLUMN month_of_year VARCHAR(10);

UPDATE amazon 
SET month_of_year = MONTHNAME(Date);

SELECT * FROM amazon;


-- # Exploratory data analysis (EDA)

-- 1. What is the count of distinct cities in the dataset?

SELECT * FROM amazon;

SELECT Count(DISTINCT City)as number_of_city, city FROM amazon 
GROUP BY city
ORDER BY number_of_city DESC;

-- Conclusion: Measurely amazon business in Myanmar is operating in three different cities as shown in the result. 

-- 2. For each branch, what is the corresponding city?
SELECT * FROM amazon;

SELECT  DISTINCT(Branch),City
FROM amazon;

-- 3. What is the count of distinct product lines in the dataset?

SELECT count(DISTINCT Product_line) FROM amazon;
 -- In Myanmar amazon is operating on 6 different product_lines 

SELECT COUNT(DISTINCT Product_line) AS number_of_product_line,product_line
FROM amazon
GROUP BY product_line
ORDER BY product_line ;

-- 4. Which payment method occurs most frequently?

SELECT * from amazon;

SELECT COUNT(Payment),Payment as pay_method FROM amazon 
GROUP BY Payment;

-- All three Payment methods are used almost equally but the most used method is Ewallet. 

-- 5. Which product line has the highest sales?
SELECT * FROM amazon;

SELECT SUM(cogs) AS Sales,Product_line  FROM amazon 
GROUP BY Product_line
ORDER BY Sales DESC;
-- OR 

SELECT SUM(Unit_price*Quantity) AS Sales,Product_line  FROM amazon 
GROUP BY Product_line
ORDER BY Sales DESC;

-- Top 5 highiest sales are made at '53471.28000000006', 'Food and beverages'
-- '53471.28000000006', 'Food and beverages'
-- '52497.93000000002', 'Sports and travel'
-- '51750.029999999984', 'Electronic accessories'
-- '51719.89999999997', 'Fashion accessories'
-- '51297.05999999998', 'Home and lifestyle'

-- 6. How much revenue is generated each month?

SELECT * from amazon;

SELECT sum(total) as REVENUE, month_of_year 
FROM amazon
GROUP BY month_of_year;

-- Total revenue in each month 

-- 7. In which month did the cost of goods sold reach its peak?

SELECT month_of_year,SUM(cogs) AS cogs_sold 
FROM amazon 
GROUP BY month_of_year 
ORDER BY cogs_sold DESC;

-- In the month of JANUARY cogs reached its peak. 

-- 8. Which product line generated the highest revenue?

SELECT Product_line, SUM(total) as Revenue 
FROM amazon 
GROUP BY Product_line 
ORDER BY Revenue DESC;

-- The product_line 'Food and beverages' made highiest revenue amoung the all 

-- 9. In which city was the highest revenue recorded?


SELECT City, SUM(total) as Revenue 
FROM amazon 
GROUP BY City
ORDER BY Revenue DESC;

--  The highest revenue recorded in 'Naypyitaw' of Myanmar 

-- Which product line incurred the highest Value Added Tax?

SELECT * FROM amazon;

SELECT product_line, SUM(Tax_5_percent)  AS total_tax FROM amazon
GROUP BY product_line 
ORDER BY total_tax DESC;

-- The product line 'Food and beverages' incured highiest value added tax

ALTER TABLE amazon 
ADD COLUMN sales_status VARCHAR(10);

UPDATE amazon A
CROSS JOIN 
(SELECT product_line, AVG(total) as avg_sales,SUM(total) as total_sales FROM amazon GROUP BY product_line) B
SET sales_status =CASE 
					WHEN total>avg_sales THEN 'Good'
                    ELSE 'Bad'
                    END
WHERE A.product_line= B.product_line;

SELECT * FROM amazon;

-- 12. Identify the branch that exceeded the average number of products sold.
SELECT * FROM amazon;


SELECT Branch,SUM(Quantity) AS Total_product_sold,AVG(Quantity) AS Avg_product_sold FROM amazon 
GROUP BY Branch HAVING
SUM(Quantity)>AVG(Quantity);

-- 13.  Which product line is most frequently associated with each gender?

SELECT Gender,Product_line,COUNT(Gender) AS frequency 
FROM amazon 
GROUP BY GENDER,Product_line 
ORDER BY Frequency DESC;

-- 14. Calculate the average rating for each product line.

SELECT Product_line,AVG(rating) as Avg_rating 
FROM amazon 
GROUP BY Product_line
ORDER BY Avg_rating DESC;

-- 15. Count the sales occurrences for each time of day on every weekday.

SELECT time_of_day,count(Quantity) as Product_sold 
FROM amazon 
GROUP BY time_of_day 
ORDER BY Product_sold DESC;


-- 16. Identify the customer type contributing the highest revenue.
SELECT * FROM amazon;

SELECT Customer_type,SUM(total) AS total_revenue
FROM amazon 
GROUP BY Customer_type 
ORDER BY total_revenue DESC;

-- 17. Determine the city with the highest VAT percentage.

SELECT * FROM amazon;

SELECT City,SUM(Tax_5_percent) as Total_tax 
FROM amazon 
GROUP BY City 
ORDER BY Total_tax DESC;

-- The city 'Naypyitaw', '5265.176500000002' giving the highiest VAT percent. 

-- 18. Identify the customer type with the highest VAT payments. 

SELECT customer_type,SUM(Tax_5_percent) AS total_tax 
FROM amazon 
GROUP BY customer_type 
ORDER BY total_tax DESC;

-- Customer_type Member contributing a highiest VAT percent. 

-- 19. What is the count of distinct customer types in the dataset?

SELECT count(DISTINCT Customer_type) AS types_of_cistomer FROM amazon;

-- 20. What is the count of distinct payment methods in the dataset?

SELECT COUNT(DISTINCT Payment) as types_of_payment 
FROM amazon;

-- 21. Which customer type occurs most frequently?

SELECT customer_type,count(*) as Frequency 
FROM amazon 
GROUP BY customer_type;

-- The frequency of occurence of both customer_type is almost same. 

-- 22. Identify the customer type with the highest purchase frequency.

SELECT * FROM amazon;

SELECT customer_type,count(*) as Frequency 
FROM amazon 
GROUP BY customer_type;


-- 23. Determine the predominant gender among customers.

SELECT gender,count(*) as gender_frequency 
FROM amazon 
GROUP BY gender 
ORDER BY gender_frequency DESC;

-- 24. Examine the distribution of genders within each branch.

SELECT Branch,Gender,count(GENDER) as frequency_of_same_gender 
FROM amazon 
GROUP BY Branch, gender
ORDER BY Branch DESC;

-- 25. Identify the time of day when customers provide the most ratings.

SELECT * FROM amazon;

SELECT time_of_day,SUM(rating) as total_rating 
FROM amazon 
GROUP BY time_of_day
ORDER BY total_rating DESC;

-- Most of the people who are purchasing into the afternoon hours gives highiest rating. 

-- 26. Identify the time of day when customers provide the most ratings.

SELECT branch,time_of_day,SUM(rating) AS total_rating 
FROM amazon 
GROUP BY branch,time_of_day
ORDER BY total_rating DESC;

-- 27. Identify the day of the week with the highest average ratings.

SELECT day_of_week,AVG(rating) as avg_rating 
FROM amazon 
GROUP BY day_of_week
ORDER BY avg_rating DESC;

-- 28. Determine the day of the week with the highest average ratings for each branch.

SELECT branch,day_of_week,AVG(rating) as avg_rating 
FROM amazon 
GROUP BY day_of_week,branch
ORDER BY avg_rating DESC;


