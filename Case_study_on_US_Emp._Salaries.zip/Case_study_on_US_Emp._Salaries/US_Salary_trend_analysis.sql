CREATE DATABASE IF NOT EXISTs Case_Studies;

USE case_studies;
SHOW TABLES;

SELECT * FROM salaries;

DESCRIBE salaries;

/* 1. You are a compensasion analyst employed by a multinational corporation. Your assignment is to pinpoint contries who give work fully 
remotely for title 'managers' Paying salaries Exceeding $90 000 USD */ 

SELECT distinct company_location FROM salaries 
WHERE remote_ratio = 100 AND 
job_title like '%manager%' AND 
salary_in_usd >90000;


/*Q2. 
AS a remote work advocate Working for a progressive HR tech startup who place their freshers’ clients IN large tech firms. 
you're tasked WITH Identifying top 5 Country Having greatest count of large (company size) number of companies.
*/

SELECT company_location,count(*)  FROM salaries 
WHERE Company_size= 'L' AND 
experience_level = 'EN'
GROUP BY company_location
ORDER BY  count(*) DESC
LIMIT 5;

/* Q3. 
Picture yourself AS a data scientist Working for a workforce management platform. Your objective is to calculate the percentage 
of employees. Who enjoy fully remote roles WITH salaries Exceeding $100,000 USD, Shedding light ON the attractiveness of high-paying 
remote positions IN today's job market.
*/

SET @Total = (SELECT COUNT(*) FROM salaries WHERE salary_in_usd>100000);
SET @county = (SELECT COUNT(*) FROM salaries WHERE salary_in_usd>10000 AND remote_ratio=100);

SET @Percentage= ((SELECT @county)/(SELECT @Total))*100;
SELECT @Percentage as 'Percentage';



/* Q4
Imagine you're a data analyst Working for a global recruitment agency. Your Task is to identify the Locations where entry-level 
average salaries exceed the average salary for that job title IN market for entry level, helping your agency guide candidates 
towards lucrative opportunities.
*/
SELECT D.job_title,P.company_location,D.avg_salaRy,P.Avg_salary_per_country 
FROM 
(
(SELECT job_title,AVG(salary_in_usd) as avg_salary 
FROM salaries 
GROUP BY job_title) D
INNER JOIN 
(SELECT job_title,company_location,AVG(salary_in_usd) as Avg_salary_per_country 
FROM salaries 
GROUP BY job_title,company_location) P
ON D.job_title=P.job_title
)WHERE D.avg_salary>P.Avg_salary_per_country;


/* Q.5
You've been hired by a big HR Consultancy to look at how much people get paid IN different Countries. Your job is to Find out for each 
job title which. Country pays the maximum average salary. This helps you to place your candidates IN those countries.
*/ 
SELECT * FROM 
(
SELECT *,dense_rank() OVER(partition by Job_title order by salary DESC) AS NUM FROM
(
SELECT job_title,company_location,AVG(salary_in_usd) AS salary
FROM salaries
GROUP BY job_title,company_location
) r
) K WHERE NUM=1;


/* Q6
AS a data-driven Business consultant, you've been hired by a multinational corporation to analyze salary trends across 
different company Locations. Your goal is to Pinpoint Locations WHERE the average salary Has consistently Increased over 
the Past few years (Countries WHERE data is available for 3 years Only(present year and past two years) providing Insights 
into Locations experiencing Sustained salary growth.
*/

SELECT * FROM SALARIES;

with Yogesh as 
(
		SELECT * FROM salaries WHERE company_location IN 
		(
		SELECT company_location FROM
		(
		SELECT company_location,avg(salary_in_usd) AS Avg_salary,COUNT(distinct(work_year)) as cnt  
		FROM salaries WHERE work_year>=(year(current_date())-2)
		GROUP BY company_location
		HAVING cnt=3) M 
		) 
)

SELECT company_location,
MAX(CASE WHEN work_year = 2022 THEN average END) AS Avg_salary_2022,
MAX(CASE WHEN work_year = 2023 THEN average END) AS Avg_salary_2023,
MAX(CASE WHEN work_year = 2024 THEN average END) AS Avg_salary_2024
FROM 
(
SELECT company_location,work_year, avg(salary_in_usd) as average FROM Yogesh GROUP BY company_location,work_year
) q GROUP BY company_location;




/*Q7
Picture yourself AS a workforce strategist employed by a global HR tech startup. Your Mission is to Determine the percentage of fully 
remote work for each experience level IN 2021 and compare it WITH the corresponding figures for 2024, Highlighting any significant 
Increases or decreases IN remote work Adoption over the years.
*/

SELECT* FROM
(
	SELECT a.experience_level,Total,cnt ,((cnt/Total))*100 AS Remote_Ratio_2021 FROM
	(
	SELECT experience_level,count(*) as Total FROM salaries WHERE work_year=2021 GROUP BY experience_level
	)a INNER JOIN 
	(
	SELECT experience_level,count(*) as cnt FROM salaries WHERE work_year=2021 AND remote_ratio=100 GROUP BY experience_level
	)b ON a.experience_level=b.experience_level
)J INNER JOIN 
(
	SELECT a.experience_level,Total,cnt ,((cnt/Total))*100 AS Remote_Ratio_2024 FROM
	(
	SELECT experience_level,count(*) as Total FROM salaries WHERE work_year=2024 GROUP BY experience_level
	)a INNER JOIN 
	(
	SELECT experience_level,count(*) as cnt FROM salaries WHERE work_year=2024 AND remote_ratio=100 GROUP BY experience_level
	)b ON a.experience_level=b.experience_level
)K ON j.experience_level=k.experience_level;


/*
AS a Compensation specialist at a Fortune 500 company, you're tasked WITH analyzing salary trends over time. Your objective is to 
calculate the average salary increase percentage for each experience level and job title between the years 2023 and 2024, helping the 
company stay competitive IN the talent market.
*/

SELECT 
    a.experience_level,
    a.job_title,
    Avg_salary_23,
    Avg_salary_24,
    (((Avg_salary_24 - Avg_salary_23) / Avg_salary_24)) * 100 AS salary_increase_perce
FROM
    ((SELECT 
        experience_level,
            job_title,
            AVG(salary_in_usd) AS Avg_salary_23
    FROM
        salaries
    WHERE
        WORK_year = 2023
    GROUP BY experience_level , job_title) a
    INNER JOIN (SELECT 
        experience_level,
            job_title,
            AVG(salary_in_usd) AS Avg_salary_24
    FROM
        salaries
    WHERE
        WORK_year = 2024
    GROUP BY experience_level , job_title) b ON a.experience_level = b.experience_level);

/*
You're a database administrator tasked with role-based access control for a company's employee database. Your goal is to implement 
a security measure where employees in different experience level (e.g. Entry Level, Senior level etc.) can only access details relevant 
to their respective experience level, ensuring data confidentiality and minimizing the risk of unauthorized access.
*/


CREATE USER 'Entry_level'@'%' identified by 'Entry'

CREATE VIEW entry_ok as 
(
SELECT* FROM SALARIES WHERE experience_level='EN'
)

GRANT SELECT ON case_studies.entry_OK TO 'Entry_level'@'%'











